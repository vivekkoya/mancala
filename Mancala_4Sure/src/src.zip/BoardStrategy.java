package src;

import java.awt.geom.Ellipse2D;

public interface BoardStrategy {
	public Ellipse2D.Double paintMarble(double x, double y);
}
